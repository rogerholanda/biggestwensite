import pyrebase
import pickle
import os
import firebase_admin
from firebase_admin import auth as firebase_auth
from firebase_admin import credentials

service_account = 'C:\Cont-X Projetos\ContXWEB\service\service_account.json'

cred = credentials.Certificate(service_account)

firebase_admin.initialize_app(cred)

firebaseConfig = {
    "apiKey": "AIzaSyAQ7VqNpdl6DAuNm6ioSmoJpeqX75hd-v4",
    "authDomain": "cont-x.firebaseapp.com",
    "databaseURL": "https://cont-x-default-rtdb.firebaseio.com",
    "projectId": "cont-x",
    "storageBucket": "cont-x.appspot.com",
    "messagingSenderId": "168073910702",
    "appId": "1:168073910702:web:e4756d986f61949dc9503f",
    "measurementId": "G-56VX4BH7WB", 
    "databaseURL":"https://cont-x-default-rtdb.firebaseio.com/"
}


firebase = pyrebase.initialize_app(firebaseConfig)
auth = firebase.auth()


def create_user(name, email, password):
    try:
        user = firebase_auth.create_user(
            email=email,
            password=password,
            display_name=name)
        return user.uid
    except:
        return None


def reset_password(email):
    try:
        auth.send_password_reset_email(email)
        return not None
    except:
        return None


def login_user(email, password):
    try:
        user = auth.sign_in_with_email_and_password(email, password)
        return user['idToken']
    except:
        return None


def store_session(token):
    if os.path.exists('token.pickle'):
        os.remove('token.pickle')
    with open('token.pickle', 'wb') as f:
        pickle.dump(token, f)


def load_token():
    try:
        with open('token.pickle', 'rb') as f:
            token = pickle.load(f)
        return token
    except:
        return None


def authenticate_token(token):
    try:
        result = firebase_auth.verify_id_token(token)

        return result['user_id']
    except:
        return None


def get_name(token):
    try:
        result = firebase_auth.verify_id_token(token)

        return result['name']
    except:
        return None


def revoke_token(token):
    result = firebase_auth.revoke_refresh_tokens(authenticate_token(token))
    if os.path.exists('token.pickle'):
        os.remove('token.pickle')
