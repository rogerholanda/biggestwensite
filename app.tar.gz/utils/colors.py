blue = "#4e73df"
white = "white"
db_text = "#2a3f5f"
